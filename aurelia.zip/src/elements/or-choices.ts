import Choices,* as Choices2 from "choices.js"
import { autoinject, bindable } from "aurelia-framework";
@autoinject()
export class OrChoices{
    public choices: any = (Choices2 as any).default || Choices2;
    public choicesElement: HTMLElement;
    public choicesInstane: Choices;
    @bindable public config: any = {};
    public attached(){
        // this.choicesInstane = this.choices(this.choicesElement);
        let x = this.choices("#choices-multiple-default",{});
    }
}